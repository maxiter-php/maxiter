# Maxiter

Check the documentation here: <a href="https://maxiter-docs.vercel.app/">Maxiter Docs</a>

# IMPORTANT

Do not send the gui.html and bash.php files to your production environment! Add them to the .gitignore file.
