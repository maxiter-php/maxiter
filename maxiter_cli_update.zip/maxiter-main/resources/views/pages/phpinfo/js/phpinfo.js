// JavaScript for phpinfo page
