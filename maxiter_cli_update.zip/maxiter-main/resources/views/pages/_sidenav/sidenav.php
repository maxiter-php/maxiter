<!--**********************************
            Sidebar start
        ***********************************-->
<div class="quixnav">
    <div class="quixnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li><a href="<?php echo EnvModel::env("APP_BASE_URL") ?>home" aria-expanded="false"><i class="icon icon-globe-2"></i><span
                                class="nav-text">Home Page</span></a></li>
            <!-- <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                        class="icon icon-single-04"></i><span class="nav-text">Cadastros</span></a>
                <ul aria-expanded="false">
                    <li><a href="./index.html">Cadastrar Arquivo</a></li>
                </ul>
            </li> -->
            <li class="nav-label">Examples</li>
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i
                        class="icon icon-app-store"></i><span class="nav-text">List</span></a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo EnvModel::env("APP_BASE_URL") ?>list-example">List Example</a></li>
                </ul>
            </li>
            
        </ul>
    </div>


</div>
<!--**********************************
            Sidebar end
        ***********************************-->