// JavaScript for auth-example page
