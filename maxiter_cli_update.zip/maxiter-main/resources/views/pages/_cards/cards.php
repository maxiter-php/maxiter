<div class="row">
    <div class="col-lg-6 col-sm-6">
        <div class="card">
            <div class="stat-widget-two card-body">
                <div class="stat-content">
                    <div class="stat-text">Card 01 </div>
                    <div class="stat-digit"> <i class="fa fa-file"></i>00</div>
                </div>
                <div class="progress">
                    <div class="progress-bar progress-bar-success w-100" role="progressbar" aria-valuenow="100"
                        aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-sm-6">
        <div class="card">
            <div class="stat-widget-two card-body">
                <div class="stat-content">
                    <div class="stat-text">Card 02</div>
                    <div class="stat-digit" id="total_sys"> <i class="fa fa-laptop"></i>00</div>
                </div>
                <div class="progress">
                    <div class="progress-bar progress-bar-primary w-100" role="progressbar" aria-valuenow="100"
                        aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- /# column -->
</div>
