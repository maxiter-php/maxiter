document.addEventListener('DOMContentLoaded', () => {

    
    // $.ajax({
    //     url: "",
    //     type: "GET",
    //     success: function (response) {

    //         console.log("FROM CARDS", response);


    //     }
    // });

});