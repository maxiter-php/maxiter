// This is the config path file, where you can change your path globally.
// 
// @author Victor Béser
var path = {
APP_BASE_URL:"http://localhost:90/maxiter/"
};